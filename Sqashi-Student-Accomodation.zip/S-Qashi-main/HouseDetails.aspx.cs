﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using PrivateAccomodation.Models;
using System.Drawing;

namespace PrivateAccomodation
{
    public partial class HouseDetails : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            currentDate.Text= DateTime.Now.ToString("yyyy-MM-dd");
            UserEmail.Text = User.Identity.Name;
            HouseID.Text = Session["itemID"].ToString();
            DataSourceSelectArguments sr = new DataSourceSelectArguments();
            DataView dv = (DataView)SqlHouseView.Select(sr);
            if (dv.Count > 0)
            {
                List<ListItem> files = new List<ListItem>();
                foreach (DataRowView rowView in dv)
                {
                    string folderName = (string)rowView["Picture"];
                    string folder = @"\image\Housespic\" + folderName + @"\";
                    string[] filesindirectory = Directory.GetFiles(Server.MapPath(folder));
                    string filename = Path.GetFileName((filesindirectory[0]));
                    Housepic.Text = folder + filename;
                    Landlorndprofile.Text = @"\image\LandlordProfile\" + (string)rowView["LandLord_EmailAddress"] + @"\.jpg";
                }
 
            }
        }
        protected void sendbtn_Click(object sender, EventArgs e)
        {
            
            BookingSql.Insert();
            succesfullRequest.Text = "Sent";
        }
        protected void viewbtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/User/HistoryRequest.aspx");
        }
        protected void RegisterS_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Account/Login.aspx");
        }
    }
}