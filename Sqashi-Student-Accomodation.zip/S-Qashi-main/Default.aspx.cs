﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using PrivateAccomodation.Models;
using System.Drawing;

namespace PrivateAccomodation
{
    public partial class _Default : Page
    {
        Hashtable imageDetails = new Hashtable();
        public DataTable HouseDetails = new DataTable();


        public DataTable MakeHouseDetailsDT(DataTable HouseDetails)
        {

            HouseDetails.Columns.Add("Picture2");
            HouseDetails.Columns.Add("StreetAddress");
            HouseDetails.Columns.Add("Area");
            HouseDetails.Columns.Add("PA_id");
            HouseDetails.Columns.Add("Price");
            return HouseDetails;
        }

        protected void ListView1_PagePropertiesChanging(object sender, PagePropertiesChangingEventArgs e)
        {
            DataPager dp = (DataPager)all.FindControl("DataPager1");
            dp.SetPageProperties(e.StartRowIndex, e.MaximumRows, false);
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            DataSourceSelectArguments sr = new DataSourceSelectArguments();
            DataView dv = (DataView)SqlHouseView.Select(sr);
            HouseDetails = MakeHouseDetailsDT(HouseDetails);
            if (dv.Count > 0)
            {
                foreach (DataRowView rowView in dv)
                {
                    string folderName = (string)rowView["Picture"];
                    string folder = @"\image\Housespic\" + folderName + @"\";
                    string[] filesindirectory = Directory.GetFiles(Server.MapPath(folder));
                    for (int i = 0; i < 1; i++)
                    {
                        string filename = Path.GetFileName((filesindirectory[0]));
                        DataRow HouseRow = HouseDetails.NewRow();
                        HouseRow["Picture2"] = folder + filename;
                        HouseRow["StreetAddress"] = (string)rowView["StreetAddress"];
                        HouseRow["Area"] = (string)rowView["Area"];
                        HouseRow["PA_id"] = rowView["PA_id"].ToString();
                        HouseRow["Price"] = rowView["Price"].ToString();
                        HouseDetails.Rows.Add(HouseRow);
                    }

                }

                all.DataSource = HouseDetails;
                all.DataBind();
            }
        }
        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            LinkButton b = (LinkButton)sender;
            string value = b.CommandArgument;
            Session["itemID"] = value;
            Response.Redirect("~/HouseDetails.aspx");
        }
    }
}